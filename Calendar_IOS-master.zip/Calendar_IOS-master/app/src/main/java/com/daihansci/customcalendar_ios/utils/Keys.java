package com.daihansci.customcalendar_ios.utils;

public class Keys {
    public static final String EMPTY = "empty";
}
