package com.daihansci.customcalendar_ios.ui.viewmodel;

import androidx.lifecycle.ViewModel;

public class EmptyViewModel extends ViewModel {
}
